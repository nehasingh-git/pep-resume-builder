import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { BrowserRouter } from 'react-router-dom'; 
import { Provider } from 'react-redux';
import {createStore} from 'redux';
import update from 'immutability-helper';

const initialState ={
  skinCd:'',
  educationSection: {},
  contactSection: {'FNAM':"Test User","PROF":"test Profession","CITY":"Delhi"}
}


function rootReducer(state=initialState, action){

 switch(action.type){
  //  case 'ADD_CONTACT':
  //    {
  //      var tempState = {...state, contactSection: action.contactSection };
  //     return tempState;
  //    }

     case 'ADD_CONTACT':
      {
       return update(state ,{contactSection:{$merge:action.contactSection }});
      }

    case 'ADD_EDUCATION':
      {
        return update(state ,{educationSection:{$merge:action.educationSection }});
      }
    case 'ADD_SKINCD':
      {
        return update(state ,{skinCd:{$set:action.skinCd }});
      }

   default:
     return state;  

 }
 
}
const store = createStore(rootReducer)

ReactDOM.render(
  <Provider store={store}>
    <BrowserRouter>
      <App />
    </BrowserRouter>,
  </Provider>,
  document.getElementById('root')
);