import React from 'react';
import logo from "../../static/images/resume.png";
import { NavLink } from "react-router-dom";
const Login = () => {
    return (    
    
        <div className="  header-no-padding-no-extra login-page">          
        <div className="section">
         <h1 className="App-title">Login Page</h1>
           
         </div>        
         </div>
    
        );
}
 
export default Login;