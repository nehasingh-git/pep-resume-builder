import React from 'react';
import ResumePreview from './resumePreview';
import {skinCodes} from '../../constants/typeCodes';
import {connect} from 'react-redux';

 class FinaliZePage extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
        educationSection: this.props.educationSection,
        contactSection: this.props.contactSection,
        skinCd: this.props.skinCd ? this.props.skinCd : 'skin1'
    };
  }

  onChange = (value) => {
      this.props.addSkin(value);
  } 

  componentWillMount(){
    window.scrollTo(0, 0);
  }
  componentWillReceiveProps(nextProps){
    this.state = {
        skinCd: nextProps.skinCd ? nextProps.skinCd : 'skin1'
    };
  }
 
  render() {
  let {contactSection, educationSection, skinCd }= this.state;
      return (    
          <div className="container med finalize-page">
          <div className="funnel-section">
            <div className="finalize-preview-card">        
                 <ResumePreview contactSection={contactSection} educationSection={educationSection}  skinCd={skinCd}></ResumePreview>
            </div>   
            <div className="finalize-settings">        
            <div className="section">
                    <h1 className=" center">
                    Select a resume template to get started</h1>
                    <p className=" center">
                    You’ll be able to edit and change this template later!
                    </p>
                    <div className="styleTemplate ">
                    {
                        skinCodes.map((value, index) => {
                            return( <div className="template-card rounded-border">

                                <i className={this.state.skinCd == value?'fa fa-check-circle selected':'hide'} aria-hidden="true"></i>
                                <img  className={this.state.skinCd == value?'active':''} src={'/images/' + value + '.svg'}/>
                                <button  className="btn-select-theme" onClick={()=>this.onChange(value)}  type='button'>USE TEMPLATE</button>    
                            </div>);    
                        })
                    }
                    </div>
                
                </div>
            </div>      
          </div>
        </div>
      );
  }

}


const mapStateToProps=(state, ownProps)=>{
    return state;
  }
  
  const mapDispatchToProps = (dispatch) =>{
    return{
        addSkin :(skinCd) => {            
            dispatch({ type: 'ADD_SKINCD',skinCd})        
        }
    }
}
   
  export default connect(mapStateToProps, mapDispatchToProps)(FinaliZePage)