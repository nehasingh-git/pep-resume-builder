import {connect} from 'react-redux';
import GettingStarted from '../presentation/gettingStarted';

const mapStateToProps=(state, ownProps)=>{
    return state;
}

const mapDispatchToProps = (dispatch) =>{
    return{
        addSkin :(skinCd) => {            
            dispatch({ type: 'ADD_SKINCD',skinCd})        
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(GettingStarted)