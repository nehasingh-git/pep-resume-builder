
import {connect} from 'react-redux';
import Contact from '../presentation/contact';

const mapStateToProps=(state, ownProps)=>{
    return state;
}

const mapDispatchToProps = (dispatch) =>{
    return{
        addContact :(contactSection) => {            
            dispatch({ type: 'ADD_CONTACT',contactSection:contactSection })        
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Contact)